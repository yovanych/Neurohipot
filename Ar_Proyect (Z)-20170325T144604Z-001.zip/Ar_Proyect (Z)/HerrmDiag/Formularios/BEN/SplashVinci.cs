using System.Windows.Forms;

namespace HerrmDiag.BEN
{
    public partial class SplashVinci : Form
    {
        public SplashVinci()
        {
            InitializeComponent();
        }
    }
}
namespace HerrmDiag.Formularios.CommonForms
{
    partial class FormConfAtencionSostenidaCompleja
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.confASCImagenesUF1 = new HerrmDiag.UserControls.ConfASCImagenesUC();
            this.SuspendLayout();
            // 
            // confASCImagenesUF1
            // 
            this.confASCImagenesUF1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.confASCImagenesUF1.Location = new System.Drawing.Point(0, 2);
            this.confASCImagenesUF1.Name = "confASCImagenesUF1";
            this.confASCImagenesUF1.ShowCancelButton = true;
            this.confASCImagenesUF1.Size = new System.Drawing.Size(283, 478);
            this.confASCImagenesUF1.TabIndex = 0;
            this.confASCImagenesUF1.AfterAcept += new HerrmDiag.UserControls.ConfASCImagenesUC.Clic_Delegate(this.bAceptar_Click_1);
            this.confASCImagenesUF1.AfterPresets += new HerrmDiag.UserControls.ConfASCImagenesUC.Clic_Delegate(this.buttonPredeterminados_Click);
            this.confASCImagenesUF1.AfterCancel += new HerrmDiag.UserControls.ConfASCImagenesUC.Clic_Delegate(this.bCancelar_Click_1);
            // 
            // FormConfAtencionSostenidaCompleja
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 480);
            this.Controls.Add(this.confASCImagenesUF1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormConfAtencionSostenidaCompleja";
            this.ShowInTaskbar = false;
            this.Text = "Configuraci�n [Atenci�n Sostenida 2]";
            this.ResumeLayout(false);

        }

        #endregion

        private UserControls.ConfASCImagenesUC confASCImagenesUF1;
    }
}
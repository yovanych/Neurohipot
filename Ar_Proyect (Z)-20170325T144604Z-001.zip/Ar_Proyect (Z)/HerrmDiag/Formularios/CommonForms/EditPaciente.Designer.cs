namespace HerrmDiag.Formularios.CommonForms
{
    partial class EditPaciente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.checkBoxNombre = new System.Windows.Forms.CheckBox();
            this.checkBoxApellido1 = new System.Windows.Forms.CheckBox();
            this.textBoxDireccion = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxNombre = new System.Windows.Forms.TextBox();
            this.textBoxApellido2 = new System.Windows.Forms.TextBox();
            this.textBoxApellido1 = new System.Windows.Forms.TextBox();
            this.labelDir = new System.Windows.Forms.Label();
            this.domainUpDownSexo = new System.Windows.Forms.DomainUpDown();
            this.textBoxCodigo = new System.Windows.Forms.TextBox();
            this.labelFechaNac = new System.Windows.Forms.Label();
            this.checkBoxSexo = new System.Windows.Forms.CheckBox();
            this.checkBoxCodigo = new System.Windows.Forms.CheckBox();
            this.checkBoxApellido2 = new System.Windows.Forms.CheckBox();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.buttonCerrar = new System.Windows.Forms.Button();
            this.textBoxNivel = new System.Windows.Forms.TextBox();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.buttonAction = new System.Windows.Forms.Button();
            this.dtpFechaNacimiento = new System.Windows.Forms.DateTimePicker();
            this.llNuevoLugar = new System.Windows.Forms.LinkLabel();
            this.cbLugar = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(-1, -15);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(163, 13);
            this.linkLabel1.TabIndex = 69;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Seleccionar todos los par�metros";
            // 
            // checkBoxNombre
            // 
            this.checkBoxNombre.AutoSize = true;
            this.checkBoxNombre.Location = new System.Drawing.Point(13, 33);
            this.checkBoxNombre.Name = "checkBoxNombre";
            this.checkBoxNombre.Size = new System.Drawing.Size(66, 17);
            this.checkBoxNombre.TabIndex = 8;
            this.checkBoxNombre.Text = "Nombre:";
            this.checkBoxNombre.UseVisualStyleBackColor = true;
            // 
            // checkBoxApellido1
            // 
            this.checkBoxApellido1.AutoSize = true;
            this.checkBoxApellido1.Location = new System.Drawing.Point(13, 59);
            this.checkBoxApellido1.Name = "checkBoxApellido1";
            this.checkBoxApellido1.Size = new System.Drawing.Size(98, 17);
            this.checkBoxApellido1.TabIndex = 9;
            this.checkBoxApellido1.Text = "Primer Apellido:";
            this.checkBoxApellido1.UseVisualStyleBackColor = true;
            // 
            // textBoxDireccion
            // 
            this.textBoxDireccion.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.textBoxDireccion.Location = new System.Drawing.Point(93, 213);
            this.textBoxDireccion.Name = "textBoxDireccion";
            this.textBoxDireccion.Size = new System.Drawing.Size(256, 20);
            this.textBoxDireccion.TabIndex = 7;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(13, 189);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 13);
            this.label11.TabIndex = 63;
            this.label11.Text = "Grado Escolar:";
            // 
            // textBoxNombre
            // 
            this.textBoxNombre.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBoxNombre.Location = new System.Drawing.Point(133, 31);
            this.textBoxNombre.Name = "textBoxNombre";
            this.textBoxNombre.Size = new System.Drawing.Size(216, 20);
            this.textBoxNombre.TabIndex = 0;
            // 
            // textBoxApellido2
            // 
            this.textBoxApellido2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.textBoxApellido2.Location = new System.Drawing.Point(133, 83);
            this.textBoxApellido2.Name = "textBoxApellido2";
            this.textBoxApellido2.Size = new System.Drawing.Size(216, 20);
            this.textBoxApellido2.TabIndex = 2;
            // 
            // textBoxApellido1
            // 
            this.textBoxApellido1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.textBoxApellido1.Location = new System.Drawing.Point(133, 57);
            this.textBoxApellido1.Name = "textBoxApellido1";
            this.textBoxApellido1.Size = new System.Drawing.Size(216, 20);
            this.textBoxApellido1.TabIndex = 1;
            // 
            // labelDir
            // 
            this.labelDir.AutoSize = true;
            this.labelDir.Location = new System.Drawing.Point(13, 216);
            this.labelDir.Name = "labelDir";
            this.labelDir.Size = new System.Drawing.Size(55, 13);
            this.labelDir.TabIndex = 64;
            this.labelDir.Text = "Direcci�n:";
            // 
            // domainUpDownSexo
            // 
            this.domainUpDownSexo.Items.Add("Masculino");
            this.domainUpDownSexo.Items.Add("Femenino");
            this.domainUpDownSexo.Location = new System.Drawing.Point(133, 136);
            this.domainUpDownSexo.Name = "domainUpDownSexo";
            this.domainUpDownSexo.Size = new System.Drawing.Size(93, 20);
            this.domainUpDownSexo.TabIndex = 4;
            this.domainUpDownSexo.Text = "Masculino";
            // 
            // textBoxCodigo
            // 
            this.textBoxCodigo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.textBoxCodigo.BackColor = System.Drawing.Color.White;
            this.textBoxCodigo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxCodigo.Location = new System.Drawing.Point(133, 109);
            this.textBoxCodigo.Name = "textBoxCodigo";
            this.textBoxCodigo.Size = new System.Drawing.Size(116, 20);
            this.textBoxCodigo.TabIndex = 3;
            // 
            // labelFechaNac
            // 
            this.labelFechaNac.AutoSize = true;
            this.labelFechaNac.Location = new System.Drawing.Point(13, 164);
            this.labelFechaNac.Name = "labelFechaNac";
            this.labelFechaNac.Size = new System.Drawing.Size(111, 13);
            this.labelFechaNac.TabIndex = 61;
            this.labelFechaNac.Text = "Fecha de Nacimiento:";
            // 
            // checkBoxSexo
            // 
            this.checkBoxSexo.AutoSize = true;
            this.checkBoxSexo.Location = new System.Drawing.Point(13, 137);
            this.checkBoxSexo.Name = "checkBoxSexo";
            this.checkBoxSexo.Size = new System.Drawing.Size(53, 17);
            this.checkBoxSexo.TabIndex = 12;
            this.checkBoxSexo.Text = "Sexo:";
            this.checkBoxSexo.UseVisualStyleBackColor = true;
            // 
            // checkBoxCodigo
            // 
            this.checkBoxCodigo.AutoSize = true;
            this.checkBoxCodigo.Location = new System.Drawing.Point(13, 111);
            this.checkBoxCodigo.Name = "checkBoxCodigo";
            this.checkBoxCodigo.Size = new System.Drawing.Size(62, 17);
            this.checkBoxCodigo.TabIndex = 11;
            this.checkBoxCodigo.Text = "C�digo:";
            this.checkBoxCodigo.UseVisualStyleBackColor = true;
            // 
            // checkBoxApellido2
            // 
            this.checkBoxApellido2.AutoSize = true;
            this.checkBoxApellido2.Location = new System.Drawing.Point(13, 85);
            this.checkBoxApellido2.Name = "checkBoxApellido2";
            this.checkBoxApellido2.Size = new System.Drawing.Size(112, 17);
            this.checkBoxApellido2.TabIndex = 10;
            this.checkBoxApellido2.Text = "Segundo Apellido:";
            this.checkBoxApellido2.UseVisualStyleBackColor = true;
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Location = new System.Drawing.Point(17, 9);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(163, 13);
            this.linkLabel2.TabIndex = 70;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Seleccionar todos los par�metros";
            this.linkLabel2.Visible = false;
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // buttonCerrar
            // 
            this.buttonCerrar.BackColor = System.Drawing.Color.DimGray;
            this.buttonCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCerrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCerrar.ForeColor = System.Drawing.Color.White;
            this.buttonCerrar.Location = new System.Drawing.Point(274, 349);
            this.buttonCerrar.Name = "buttonCerrar";
            this.buttonCerrar.Size = new System.Drawing.Size(75, 23);
            this.buttonCerrar.TabIndex = 14;
            this.buttonCerrar.Text = "Cerrar";
            this.buttonCerrar.UseVisualStyleBackColor = false;
            this.buttonCerrar.Click += new System.EventHandler(this.buttonCerrar_Click);
            // 
            // textBoxNivel
            // 
            this.textBoxNivel.Location = new System.Drawing.Point(133, 186);
            this.textBoxNivel.Name = "textBoxNivel";
            this.textBoxNivel.Size = new System.Drawing.Size(93, 20);
            this.textBoxNivel.TabIndex = 6;
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.Location = new System.Drawing.Point(271, 112);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(45, 13);
            this.linkLabel3.TabIndex = 71;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "Generar";
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel3_LinkClicked);
            // 
            // buttonAction
            // 
            this.buttonAction.BackColor = System.Drawing.Color.DimGray;
            this.buttonAction.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAction.ForeColor = System.Drawing.Color.White;
            this.buttonAction.Location = new System.Drawing.Point(5, 349);
            this.buttonAction.Name = "buttonAction";
            this.buttonAction.Size = new System.Drawing.Size(75, 23);
            this.buttonAction.TabIndex = 13;
            this.buttonAction.Text = "Agregar";
            this.buttonAction.UseVisualStyleBackColor = false;
            this.buttonAction.Click += new System.EventHandler(this.buttonAction_Click);
            // 
            // dtpFechaNacimiento
            // 
            this.dtpFechaNacimiento.Location = new System.Drawing.Point(133, 161);
            this.dtpFechaNacimiento.Name = "dtpFechaNacimiento";
            this.dtpFechaNacimiento.Size = new System.Drawing.Size(216, 20);
            this.dtpFechaNacimiento.TabIndex = 72;
            // 
            // llNuevoLugar
            // 
            this.llNuevoLugar.AutoSize = true;
            this.llNuevoLugar.Location = new System.Drawing.Point(294, 325);
            this.llNuevoLugar.Name = "llNuevoLugar";
            this.llNuevoLugar.Size = new System.Drawing.Size(48, 13);
            this.llNuevoLugar.TabIndex = 78;
            this.llNuevoLugar.TabStop = true;
            this.llNuevoLugar.Text = "Nuevo...";
            this.llNuevoLugar.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llNuevoLugar_LinkClicked);
            // 
            // cbLugar
            // 
            this.cbLugar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbLugar.FormattingEnabled = true;
            this.cbLugar.Location = new System.Drawing.Point(13, 294);
            this.cbLugar.Name = "cbLugar";
            this.cbLugar.Size = new System.Drawing.Size(336, 21);
            this.cbLugar.TabIndex = 77;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 273);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 13);
            this.label2.TabIndex = 76;
            this.label2.Text = "Lugar de aplicaci�n:";
            // 
            // EditPaciente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(356, 384);
            this.Controls.Add(this.llNuevoLugar);
            this.Controls.Add(this.cbLugar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtpFechaNacimiento);
            this.Controls.Add(this.linkLabel3);
            this.Controls.Add(this.textBoxNivel);
            this.Controls.Add(this.buttonCerrar);
            this.Controls.Add(this.linkLabel2);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.buttonAction);
            this.Controls.Add(this.checkBoxNombre);
            this.Controls.Add(this.checkBoxApellido1);
            this.Controls.Add(this.textBoxDireccion);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBoxNombre);
            this.Controls.Add(this.textBoxApellido2);
            this.Controls.Add(this.textBoxApellido1);
            this.Controls.Add(this.labelDir);
            this.Controls.Add(this.domainUpDownSexo);
            this.Controls.Add(this.textBoxCodigo);
            this.Controls.Add(this.labelFechaNac);
            this.Controls.Add(this.checkBoxSexo);
            this.Controls.Add(this.checkBoxCodigo);
            this.Controls.Add(this.checkBoxApellido2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "EditPaciente";
            this.ShowInTaskbar = false;
            this.Text = "EditPaciente";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.CheckBox checkBoxNombre;
        private System.Windows.Forms.CheckBox checkBoxApellido1;
        private System.Windows.Forms.TextBox textBoxDireccion;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxNombre;
        private System.Windows.Forms.TextBox textBoxApellido2;
        private System.Windows.Forms.TextBox textBoxApellido1;
        private System.Windows.Forms.Label labelDir;
        private System.Windows.Forms.DomainUpDown domainUpDownSexo;
        private System.Windows.Forms.TextBox textBoxCodigo;
        private System.Windows.Forms.Label labelFechaNac;
        private System.Windows.Forms.CheckBox checkBoxSexo;
        private System.Windows.Forms.CheckBox checkBoxCodigo;
        private System.Windows.Forms.CheckBox checkBoxApellido2;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.Button buttonCerrar;
        private System.Windows.Forms.TextBox textBoxNivel;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.Button buttonAction;
        private System.Windows.Forms.DateTimePicker dtpFechaNacimiento;
        private System.Windows.Forms.LinkLabel llNuevoLugar;
        private System.Windows.Forms.ComboBox cbLugar;
        private System.Windows.Forms.Label label2;
    }
}
﻿namespace PDF_Report
{
    public enum TestType2Report
    {
        Imagenes,
        Figuras,
        Letras
    }
    public enum TestClass2Export
    {
        Simple,
        Compleja
    }
}

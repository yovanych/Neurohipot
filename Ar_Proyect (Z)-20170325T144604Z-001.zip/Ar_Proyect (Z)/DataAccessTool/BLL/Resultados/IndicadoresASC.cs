﻿namespace DALayer
{
    public class IndicadoresASC : _Indicadores
    {
        public static string TableName = "IndicadoresASC";
        public IndicadoresASC()
            : base(TableName)
        { }
    }
}

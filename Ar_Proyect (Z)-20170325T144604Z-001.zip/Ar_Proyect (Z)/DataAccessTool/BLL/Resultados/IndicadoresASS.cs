﻿namespace DALayer
{
    public class IndicadoresASS : _Indicadores
    {
        public IndicadoresASS() 
            : base("IndicadoresASS")
        {}
    }
}

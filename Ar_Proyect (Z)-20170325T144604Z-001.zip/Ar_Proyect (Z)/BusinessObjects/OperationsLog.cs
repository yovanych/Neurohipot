﻿using System;
using System.IO;

namespace BusinessObjects
{
    //public class OperationsLog
    //{
    //    private const string file_name = "Log_.txt";

    //    public static void LogOperation( string operation )
    //    {
    //        var fi = new FileInfo( file_name );
    //        var sw = fi.AppendText();
    //        sw.WriteLine( operation );
    //        sw.Close();
    //    }

    //    public static void ClearLog()
    //    {
    //        var fi = new FileInfo( file_name );
    //        var sw = fi.CreateText();
    //        sw.Close();
    //    }
    //}
}
